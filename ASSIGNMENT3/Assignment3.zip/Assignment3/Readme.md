# Assignment 3 

###### Gruppo:

- ###### Baleotto Christian 157558

- ###### Enzo Giglio 179795

## ### Dopo aver ricompilato l'opt:

- Andare nella root directory di LLVM ed eseguire i seguenti comandi:

```
  export PATH=/root/LLVM_ROOT/INSTALL/bin:$PATH\
  BUILD/bin/opt -p loopinvariant TEST/LOOP.ll -o TEST/FINAL.bc\
  cd TEST
  llvm-dis FINAL.bc -o FINAL.ll
```



